"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Tweet = (function () {
    function Tweet() {
    }
    return Tweet;
}());
exports.Tweet = Tweet;
//# sourceMappingURL=tweet.js.map